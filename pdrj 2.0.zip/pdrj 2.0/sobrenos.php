<?php
include "controle.php"
?>

<div class="container">
    <div class="text-center fs-3 mt-4">
        <p class="mt-4">PDRJ é uma empresa que visa cadastrar pessoas perdidas em prol de encontra-las para ajudar familiares e amigos. A empresa foi fundada por um grupo de amigos, que também já perderam pessoas queridas no passado, o projeto começou pequeno apenas uma forma de divulgação em redes sociais que cresceu e virou um site de divulgações grande e conhecido. Por ser um site de divulgação ainda não temos uma sede fixa para visitas e cadastro de novas pessoas desaparecidas, por enquanto tudo pelo site e podem mandar reclamações ou duvidas pelas nossas redes sociais.</p>
    </div>
</div>
<br />
<br />

<?php
include "footer.php"
?>