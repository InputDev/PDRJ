<?php

    include "controle.php";

?>
<link rel="stylesheet" href="css/style.css">
    <div class="container mt-5 p-5 text-center ">
        <h1>Página Index</h1>
    </div>
    <?php
        include "footer.php"
    ?>