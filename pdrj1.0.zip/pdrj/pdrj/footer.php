
     <div class="container-fluid bg-dark text-white fixed-bottom p-3">
        <div class="row">
            <div class="col text-start">
               Copyright - SEU NOME
            </div>
        
        </div>
     </div>
     
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
  </body>
</html>