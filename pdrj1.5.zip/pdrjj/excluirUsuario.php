<?php

    include "../conexao.php";

        //Tratamento de erro
    if(isset($_GET['login'])){
        $id = $_GET['login'];

        //processamento
        $sql="delete from usuarios where Id = '$Id'";
        $excluir = mysqli_query($conexao,$sql);

        //saida
        if($excluir){
            echo "
            <>
                alert('Usuario excluido com Sucesso!');
                window.location = 'listarUsuario.php';
                </>
                ";

    }
    else{
        echo "
        <p> Esta é uma página de tratamento de dados. </
        <p>
        <p> Clique <a href='listarAluno.php'> aqui </a>
        para Excluir um usuario. </p>
        ";
        echo mysqli_error($conexao);
    }
}

?>
