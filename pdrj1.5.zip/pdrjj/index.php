<?php
include "controle.php";
?>

<link rel="stylesheet" href="css/style.css">


<div class="container p-5 text-center">
    <h1 class="fw-bold fs-1 title">Página Inicial</h1>
</div>




<?php
include "footer.php"
?>